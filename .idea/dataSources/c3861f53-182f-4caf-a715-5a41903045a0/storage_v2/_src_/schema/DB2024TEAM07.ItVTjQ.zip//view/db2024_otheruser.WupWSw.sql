create definer = DB2024TEAM07@localhost view db2024_otheruser as
select `db2024team07`.`db2024_user`.`user_id` AS `user_id`,
       `db2024team07`.`db2024_user`.`name`    AS `name`,
       `db2024team07`.`db2024_user`.`email`   AS `email`
from `db2024team07`.`db2024_user`;

