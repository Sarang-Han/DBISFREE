create definer = DB2024TEAM07@localhost view db2024_menuview as
select `r`.`res_name` AS `res_name`, `m`.`menu_name` AS `menu_name`, `m`.`price` AS `price`
from (`db2024team07`.`db2024_restaurant` `r` join `db2024team07`.`db2024_menu` `m` on ((`r`.`res_id` = `m`.`res_id`)));

