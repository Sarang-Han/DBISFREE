create definer = DB2024TEAM07@localhost view db2024_viewreview as
select `db2024team07`.`db2024_review`.`review_id`      AS `review_id`,
       `db2024team07`.`db2024_user`.`name`             AS `name`,
       `db2024team07`.`db2024_menu`.`menu_name`        AS `menu_name`,
       `db2024team07`.`db2024_review`.`rating`         AS `rating`,
       `db2024team07`.`db2024_review`.`review_content` AS `review_content`
from `db2024team07`.`db2024_user`
         join `db2024team07`.`db2024_menu`
         join `db2024team07`.`db2024_review`
where ((`db2024team07`.`db2024_user`.`user_id` = `db2024team07`.`db2024_review`.`user_id`) and
       (`db2024team07`.`db2024_menu`.`menu_id` = `db2024team07`.`db2024_review`.`menu_id`));

